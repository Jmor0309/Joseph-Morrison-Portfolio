Upload the contents of this folder to the root of your GitHub repository.

Required GitHub Pages setting:
- Branch: main
- Folder: /(root)

Main website file:
- index.html

Optional:
- If GitHub Pages was already enabled, wait a few minutes after upload for the site to deploy.
